#include "simulation.h"

Simulation::Simulation()
{

}
