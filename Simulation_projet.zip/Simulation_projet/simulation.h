#ifndef SIMULATION_H
#define SIMULATION_H


class Simulation
{





public:
    Simulation();
    ~Simulation();





};

#endif // SIMULATION_H
